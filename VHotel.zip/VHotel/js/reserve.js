function validate() {
  const name = document.getElementById("name").value;
  const phone = document.getElementById("telepon").value;
  const room = document.getElementById("room").value;
  const checkIn = document.getElementById("check-in").value;
  const checkOut = document.getElementById("check-out").value;
  const errorElement = document.getElementById("error");

  if (name.length === 0) {
    text = "Please fill in your name";
    errorElement.innerHTML = text;
    return false;
  }
  if (phone.length === 0) {
    text = "Please fill in your phone number";
    errorElement.innerHTML = text;
    return false;
  }
  if (room.length === 0) {
    text = "Please fill in your room";
    errorElement.innerHTML = text;
    return false;
  }
  if (checkIn.length === 0) {
    text = "Please fill in your check in date";
    errorElement.innerHTML = text;
    return false;
  }
  if (checkOut.length === 0) {
    text = "Please fill in your check out date";
    errorElement.innerHTML = text;
    return false;
  }

  alert("Order Successfull");
  return true;
}

let slideIndex = 1;
showSlidesThree(slideIndex);

function plusSlidesThree(n) {
  showSlidesThree((slideIndex += n));
}

function currentSlideThree(n) {
  showSlidesThree((slideIndex = n));
}

function showSlidesThree(n) {
  let i;
  let slides = document.getElementsByClassName("slides3");
  let dots = document.getElementsByClassName("dot3");
  if (n > slides.length) {
    slideIndex = 1;
  } else if (n < 1) {
    slideIndex = slides.length;
  }
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex - 1].style.display = "block";
  dots[slideIndex - 1].className += " active";
  return;
}
